package cl.duoc.app.model

data class FormularioServicioErrores(
    val nombreCliente: String? = null,
    val correoCliente: String? = null
)
